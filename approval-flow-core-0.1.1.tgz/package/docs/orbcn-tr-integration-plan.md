# ORBCN_TR 嵌入式接入 @approval-flow/core 实施计划

> 目标：把审批引擎以 npm 包形式嵌入 ORBCN_TR（差旅报销系统）的 Next.js 服务端，替换现有手写单步审批，获得多级审批、条件路由、退回重提、审计轨迹、幂等与并发保护能力。
> 引擎仓库：`git@github.com:AlbertZhang1234/approval_process.git`

## 0. 已确认的决策

| 决策项 | 结论 |
|---|---|
| 集成形态 | 单系统嵌入（非中心化服务），进程内调用 |
| 历史数据 | 不迁移。已审批的旧单保持原样，旧接口保留服务存量展示 |
| 审批链 | workflow JSON 配置，版本化发布，可迭代（v1 简单起步） |
| 升级节点审批人 | 角色（`otto_role` / `otto_userrole`） |
| 第一节点审批人 | 项目经理（`otto_project.projectmanager`，`PROVIDER` 策略实时解析） |
| 幂等键 | `tr:{trno}`（报销单号天然唯一） |

## 1. 勘察结论（两系统现状事实）

### ORBCN_TR（宿主）
- **技术栈**：Next.js 15 App Router + React 19 + TS，Node v24（满足引擎 ≥20.9）。
- **数据库**：自托管 Supabase PostgreSQL。应用内有两条数据通道：`services/_core/supabaseRest`（REST CRUD）和 `lib/db.ts`（`pg` 连接池，读 `DATABASE_URL`）。
- **关键表**：`otto_user`（userid/email/姓名，**无 manager 字段**）、`otto_role` + `otto_userrole`、`otto_project`（projectmanager/salesperson）、`otto_tr_h`（报销单头：id/userid/projectid/trno/approvalstatus/approver）、`otto_tr_t`（明细行：tr_amount）。
- **现有审批**：`app/api/reimbursement/approve|approval-action|sendto*` 单步审批，状态 `open → wait for approval → approved/rejected`，审批后 nodemailer 通知财务与申请人，通过后走 SAP posting。**保留不动，服务存量单据。**
- **已有可复用资产**：`instrumentation.ts` 已有后台 worker 注册模式（supplier-draft）；邮件服务（nodemailer）；`requireApiAuth` 鉴权；`permissions.isAdmin/isFinance`。

### 引擎侧
- 迁移建独立 `approval` + `approval_api` schema，与 `otto_*` 表**零冲突**，可整 schema 回滚。
- `PostgresApprovalStore` 基于 `postgres`（postgres.js）驱动，与现有 `pg` 池并存。
- 公开 API：`createApprovalModule({ store, organizationProvider, clock?, idGenerator?, policies? })`、`createOutboxWorker(options)`、`createWorkflowManager()`（草稿/校验/发布/版本审计）、`ApprovalEmailNotifier`。入口 `@approval-flow/core`，存储 `@approval-flow/core/postgres`。

## 2. 前置准备

### 2.1 引擎仓库（approval_process）
1. 给当前代码打 tag 并推送：`git tag v0.1.0 && git push origin v0.1.0`。TR 引用固定 tag，不要引用分支（生产依赖需要可复现）。
2. （已知问题，不阻塞）`prepack` 会在 TR 侧安装时跑 typecheck + 全量测试 + 构建，首次安装数分钟。后续可在引擎仓库加 `prepare` 精简脚本优化。

### 2.2 TR 侧环境核查（阶段 1 开工前确认）
1. **连接串一致性**：`lib/db.ts` 用的 `DATABASE_URL` 与实际业务库（即 `supabaseRest` 访问的库）是同一个。迁移和引擎 Store 必须指向业务库。
2. **网络可达性**：应用服务器能直连 Postgres 5432 端口（引擎 Postgres 适配器需要 TCP 直连；`pg` 池能用即满足）。
3. **安全整改（强烈建议同批处理）**：`Backend/Database/migration/migrate_pg.js` 硬编码了连接串和密码且已进 git 历史。改造为读环境变量，并**轮换该密码**。
4. **建角色**：在 `otto_role` 新建 `senior-approver`（名称可自定），在 `otto_userrole` 挂上大额审批人。

## 3. 分阶段实施

### 阶段 1：依赖与数据库（约半天）

**依赖安装**（`Frontend/package.json`）：

```json
{
  "dependencies": {
    "@approval-flow/core": "git+ssh://git@github.com:AlbertZhang1234/approval_process.git#v0.1.0",
    "postgres": "^3.4.9"
  }
}
```

> 用 HTTPS 还是 SSH 按团队 git 凭据习惯二选一；`postgres` 是引擎 Postgres 适配器的 peer 依赖。

**应用迁移**：把 `approval_process/supabase/migrations/` 下两个 SQL（按文件名顺序）在业务库执行一次。建议并入 TR 现有迁移流程（仿 `migrate_pg.js`，但连接串读环境变量），或直接在 Supabase SQL 编辑器按序执行。

**验收**：库中出现 `approval.*` 表；`otto_*` 表无任何变化。

### 阶段 2：装配模块（约 1 天）

位置：`Frontend/services/Approval/`，遵循现有 services 分层 + 入口组装约定（TR 的 AGENTS.md 规则：不靠模块级全局单例，依赖入口处组装）。

```
services/Approval/
  store.ts              # createPostgresApprovalStore({ connectionString: process.env.DATABASE_URL })
  organization.ts       # OrganizationProvider + UserContactProvider 实现
  email-sender.ts       # 复用现有 nodemailer 邮件服务实现引擎 EmailSender 端口
  module.ts             # createApprovalModule({ store, organizationProvider })，导出装配函数
  workflows.ts          # v1 流程定义与发布守护
```

**`organization.ts` 是核心**，实现 `resolveAssignees(policy, ctx)`：

- `PROVIDER "project-manager"`：从 `ctx.business.id` 或 `ctx.context.projectid` 查 `otto_project.projectmanager`，返回 `[userid]`。
- `ROLE <roleid>`：查 `otto_userrole` where `roleid = <value>`，返回用户列表。
- `UserContactProvider.getUserContact`：查 `otto_user` 的 email + `firstname/lastname` 拼显示名。

**发布守护**（`workflows.ts`）：启动/首次使用时检查 `store.getPublishedWorkflow("travel-reimbursement")`，不存在则 `store.publish(v1定义)`。后续改流程走版本递增发布（要管理界面时再上 `createWorkflowManager` 的草稿/校验/发布流程）。

### 阶段 3：流程定义 v1（约半天）

```json
{
  "key": "travel-reimbursement",
  "name": "差旅报销审批",
  "version": 1,
  "nodes": [
    { "id": "start", "type": "START", "name": "开始" },
    {
      "id": "pm_review", "type": "APPROVAL", "name": "项目经理审批",
      "config": {
        "mode": "ANY",
        "assignees": [{ "type": "PROVIDER", "value": "project-manager" }],
        "emptyAssigneePolicy": "ERROR",
        "selfApprovalPolicy": "REQUIRE_OTHER"
      }
    },
    { "id": "amount_gate", "type": "CONDITION", "name": "金额判断" },
    {
      "id": "senior_review", "type": "APPROVAL", "name": "高额审批",
      "config": {
        "mode": "ANY",
        "assignees": [{ "type": "ROLE", "value": "senior-approver" }],
        "emptyAssigneePolicy": "ERROR",
        "selfApprovalPolicy": "REQUIRE_OTHER"
      }
    },
    { "id": "approved_end", "type": "END", "name": "审批通过" }
  ],
  "edges": [
    { "id": "e1", "source": "start", "target": "pm_review" },
    { "id": "e2", "source": "pm_review", "target": "amount_gate" },
    {
      "id": "e_high", "source": "amount_gate", "target": "senior_review", "priority": 10,
      "condition": { "field": "amount", "operator": "GTE", "value": 5000 }
    },
    { "id": "e_normal", "source": "amount_gate", "target": "approved_end", "default": true },
    { "id": "e3", "source": "senior_review", "target": "approved_end" }
  ]
}
```

阈值 `5000` 为占位，按实际业务定。结构照抄 `examples/reimbursement.workflow.json`，只改了第一节点策略（`MANAGER` → `PROVIDER`）和升级节点角色。

### 阶段 4：业务接线（约 1.5 天）

**4.1 提交侧**（改 `services/TravelReimbursement` 的创建/提交流程）：

建单成功（拿到 `trno`、汇总 `otto_tr_t` 金额总额）后：

```ts
await approval.start({
  idempotencyKey: `tr:${trno}`,
  definitionKey: "travel-reimbursement",
  business: { type: "tr", id: trno, url: `/ reimbursement 单据详情路由/${trno}` },
  applicantId: userid,
  context: { amount: 总金额, projectid, ... },
});
```

- `otto_tr_h.approvalstatus` 初始写 `'wait for approval'`（沿用现有取值，前端零改动兼容）。
- `approver` 字段可停写（引擎任务表自持审批人），保留列兼容旧展示。
- 驳回后修改重提：不重新 `start`，调 `approval.updateContext({ instanceId, context: 新上下文 })`，`contextRevision` 递增、条件按新金额重路由。
- **灰度开关**：新提交是否走引擎由环境变量控制（如 `TR_APPROVAL_ENGINE=1`），出问题可切回旧逻辑。

**4.2 结果侧**（Outbox worker，挂 `instrumentation.ts`，仿现有 supplier-draft worker 模式）：

`createOutboxWorker` 的事件处理映射：

| 事件 | 处理 |
|---|---|
| `approval.task.created` | 给审批人发待办邮件（复用现有审批请求邮件，正文带详情链接） |
| `approval.instance.approved` | 回写 `otto_tr_h.approvalstatus = 'APPROVED'`；触发现有 `notifyFinance`（SAP posting 链路保持不动） |
| `approval.instance.rejected` / `withdrawn` / `canceled` | 回写状态 + 触发现有 `notifyApplicant` |
| 其余（started/resubmitted/returned/task.completed） | v1 忽略或记日志 |

- 事件按 `eventId` 幂等（worker 为 at-least-once 投递）。
- 事件里带 `business.id = trno`，回查 `otto_tr_h` 拿 header id 后复用现有通知函数。
- 邮件也可整体交给引擎的 `ApprovalEmailNotifier`（内置模板 + 渲染器），二选一：**v1 建议复用现有邮件函数**（文案不变），后续再迁。

**4.3 权限**：新审批路由先 `requireApiAuth`，再校验当前用户是引擎任务的 assignee（任务本身已绑定审批人，校验比旧的 `canActAsApprover` 更简单严格）。admin 保留 `cancel` 管理能力。

### 阶段 5：审批 API 与前端（约 2-3 天）

**API**（`app/api/approval/`，一个 route 只做参数解析 → service → 响应转换）：

| 路由 | 用途 |
|---|---|
| `GET  /api/approval/tasks` | 我的待办（`queryTasks` 分页，可按 businessType 过滤） |
| `POST /api/approval/tasks/:id/actions` | 同意 / 驳回（`REJECT_TO_APPLICANT`）/ 驳回指定节点 |
| `GET  /api/approval/instances/by-business` | 详情页反查实例 + 轨迹（`getInstanceByBusiness`） |
| `POST /api/approval/instances/:id/withdraw` | 申请人撤回 |
| `POST /api/approval/instances/:id/context` | 驳回后修改重提 |

**前端**（`app/pc/` 下按现有页面模式，v1 最小集）：

1. 我的待办列表（或首页待办卡片）。
2. 报销单详情页：审批状态徽标 + 流程轨迹时间线 +（审批人）同意/驳回按钮 +（申请人）撤回、驳回后修改重提。
3. demo 页 `approval_process/demo/public/index.html` 的交互可直接参考。

### 阶段 6：验证与上线（约 1 天）

必测场景（手工 E2E + 关键 service 单测）：

1. **小额单**：提交 → PM 待办 → 同意 → `APPROVED` + 财务邮件 + SAP 链路照旧。
2. **大额单**：提交 → PM 同意 → senior-approver 待办 → 同意 → `APPROVED`。
3. **驳回重提**：驳回 → 申请人改金额/明细 → `updateContext` 重提 → 按新金额路由（改超阈值应多走一级）。
4. **幂等**：同 `trno` 重复提交 `start` 返回同一实例，不重复发起。
5. **并发**：两人同时打开同一任务审批，后提交者得到版本冲突重试结果，状态一致。
6. **撤回**：申请人撤回 → 状态回写 → 待办消失。
7. **存量回归**：旧单详情页、旧 approve 接口行为不变。
8. **worker 重启恢复**：审批后立即重启进程，outbox 事件补投、状态最终一致。

单元测试仿 `tsx --test` 现有模式：organizationProvider 解析、事件 → 状态回写映射。

## 4. 上线与回滚

- **灰度**：`TR_APPROVAL_ENGINE` 开关控制新单走引擎/旧逻辑；先内部账号验证再放开。
- **回滚**：关开关（新单回旧逻辑）→ 在途引擎单自然走完 → 需要彻底清理时 `drop schema approval cascade; drop schema approval_api cascade;`。业务表 `otto_*` 全程未被引擎写入结构变更。

## 5. 待定参数与边界决策（开工前拍板）

| # | 事项 | 建议 |
|---|---|---|
| 1 | 大额角色 roleid 与成员 | 新建 `senior-approver`，挂财务/总监成员 |
| 2 | 金额阈值 | 业务定（示例 5000） |
| 3 | **项目经理=申请人**（自己报销自己项目） | 三选一：`ALLOW`（自审，不推荐）/ `SKIP`（跳过 PM 节点直接进金额判断）/ `REQUIRE_OTHER`+`emptyAssigneePolicy: SKIP`。建议 `SKIP`：自审失去意义，跳过后大额仍有角色节点兜底 |
| 4 | 大额是否也通知/抄送财务 | v2 决定（`ROLE finance` 变审批节点或保持邮件知会） |
| 5 | 引擎引用方式 | git tag（见 2.1），团队凭据 SSH/HTTPS 二选一 |

## 6. 风险与注意事项

1. **git 依赖安装慢**：`prepack` 跑全量测试构建（引擎测试纯内存，无需数据库，可完成但需数分钟）。不阻塞；后续在引擎仓库优化脚本。
2. **三个数据库通道并存**：`supabaseRest` + `pg` 池 + 引擎 `postgres.js` 池。注意连接池上限配置，避免打满 Supabase 连接数。
3. **硬编码凭据**：`migrate_pg.js` 的密码已进 git 历史，整改脚本的同时**必须轮换密码**。
4. **在途单据与版本锁定**：改流程发新版本只影响新单；存量在途单按发起时快照走完。紧急规则变更走撤回重提，不要期望在途单切换版本。
5. **审批人解析时机**：节点激活时实时解析。项目经理换人后，未到达的 PM 节点自动找新经理——通常符合预期，但若要求"以发起时为准"需在 TR 侧固化解析结果。
6. **旧接口下线**：`sendtoapprover` 等旧邮件触发接口对引擎单不再调用；观察一个周期后下线。

## 7. 工作量汇总

| 阶段 | 内容 | 估时 |
|---|---|---|
| 1 | 依赖 + 迁移 | 0.5 天 |
| 2 | 装配模块 | 1 天 |
| 3 | 流程 v1 | 0.5 天 |
| 4 | 业务接线 + worker | 1.5 天 |
| 5 | API + 前端 | 2-3 天 |
| 6 | 验证上线 | 1 天 |
| **合计** | | **约 6-7 天（单人）** |
